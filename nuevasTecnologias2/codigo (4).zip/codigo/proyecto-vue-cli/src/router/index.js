import { createWebHistory, createRouter } from 'vue-router'

import Binding from '../components/Binding.vue'
import Estructura from '../components/Estructura.vue'
import Atributos from '../components/Atributos.vue'
import Formulario from '../components/Formulario.vue'
import FormularioVue from '../components/FormularioVue.vue'
import Http from '../components/Http.vue'

const routes = [
    { path: '/', name: 'Home', component: Binding },
    { path: '/binding', name: 'Binding', component: Binding },
    { path: '/estructura', name: 'Estructura', component: Estructura },
    { path: '/atributos', name: 'Atributos', component: Atributos },
    { path: '/formulario', name: 'Formulario', component: Formulario },
    { path: '/formulariovue', name: 'FormularioVue', component: FormularioVue },
    { path: '/http', name: 'Http', component: Http }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router


